package model;

import java.util.ArrayList;
import java.util.List;

public class Profissional extends Pessoa {
    private List<String> especialidades = new ArrayList<>();

    public Profissional(int id, String nome, String email, String telefone) {
        super(id, nome, email, telefone);
    }

    public List<String> getEspecialidades() { return especialidades; }

    public void adicionarEspecialidade(String especialidade) {
        especialidades.add(especialidade);
    }
}