package model.enums;

public enum CategoriaServico {
    ENCANAMENTO,
    ELETRICO,
    TROCA_CHUVEIRO,
    INSTALACAO_SUPORTE
}
