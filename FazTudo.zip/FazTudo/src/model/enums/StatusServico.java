package model.enums;

public enum StatusServico {
    SOLICITADO,
    EM_ANDAMENTO,
    CONCLUIDO
}
