package model;

import java.time.LocalDate;

import model.enums.CategoriaServico;
import model.enums.StatusServico;


public class Servico {
    private int id;
    private String descricao;
    private CategoriaServico categoria;
    private Cliente cliente;
    private Profissional profissional;
    private StatusServico status;
    private LocalDate dataSolicitacao;
    private LocalDate dataConclusao;

    public Servico(int id, String descricao, CategoriaServico categoria, Cliente cliente, Profissional profissional) {
        this.id = id;
        this.descricao = descricao;
        this.categoria = categoria;
        this.cliente = cliente;
        this.profissional = profissional;
        this.status = StatusServico.SOLICITADO;
        this.dataSolicitacao = LocalDate.now();
    }

    public int getId() { return id; }
    public String getDescricao() { return descricao; }
    public CategoriaServico getCategoria() { return categoria; }
    public Cliente getCliente() { return cliente; }
    public Profissional getProfissional() { return profissional; }
    public StatusServico getStatus() { return status; }
    public LocalDate getDataSolicitacao() { return dataSolicitacao; }
    public LocalDate getDataConclusao() { return dataConclusao; }

    public void setStatus(StatusServico status) {
        this.status = status;
        if (status == StatusServico.CONCLUIDO) {
            this.dataConclusao = LocalDate.now();
        }
    }
}
