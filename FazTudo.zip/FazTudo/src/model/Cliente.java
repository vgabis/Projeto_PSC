package model;

import java.util.ArrayList;
import java.util.List;

public class Cliente extends Pessoa {
    private String endereco;
    private List<Servico> servicosSolicitados = new ArrayList<>();

    public Cliente(int id, String nome, String email, String telefone, String endereco) {
        super(id, nome, email, telefone);
        this.endereco = endereco;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public List<Servico> getServicosSolicitados() {
        return servicosSolicitados;
    }

    public void adicionarServico(Servico servico) {
        servicosSolicitados.add(servico);
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", email='" + email + '\'' +
                ", telefone='" + telefone + '\'' +
                ", endereco='" + endereco + '\'' +
                '}';
    }
}
