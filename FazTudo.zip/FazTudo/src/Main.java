import model.*;
import model.enums.*;
import service.Sistema;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Sistema sistema = new Sistema();
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Cadastrar Profissional");
            System.out.println("3. Cadastrar Serviço");
            System.out.println("4. Listar Serviços");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Nome: ");
                    String nome = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Telefone: ");
                    String telefone = scanner.nextLine();
                    System.out.print("Endereço: ");
                    String endereco = scanner.nextLine();
                    Cliente cliente = new Cliente(sistema.getClientes().size() + 1, nome, email, telefone, endereco);
                    sistema.cadastrarCliente(cliente);
                    System.out.println("Cliente cadastrado com sucesso!");
                    break;
                case 2:
                    System.out.print("Nome: ");
                    String nomeP = scanner.nextLine();
                    System.out.print("Email: ");
                    String emailP = scanner.nextLine();
                    System.out.print("Telefone: ");
                    String telefoneP = scanner.nextLine();
                    Profissional profissional = new Profissional(sistema.getProfissionais().size() + 1, nomeP, emailP, telefoneP);
                    System.out.print("Especialidade: ");
                    String esp = scanner.nextLine();
                    profissional.adicionarEspecialidade(esp);
                    sistema.cadastrarProfissional(profissional);
                    System.out.println("Profissional cadastrado com sucesso!");
                    break;
                case 3:
                    if (sistema.getClientes().isEmpty() || sistema.getProfissionais().isEmpty()) {
                        System.out.println("Cadastre pelo menos um cliente e um profissional primeiro.");
                        break;
                    }
                    System.out.print("Descrição do serviço: ");
                    String desc = scanner.nextLine();
                    System.out.println("Categoria (ENCANAMENTO, ELETRICO, TROCA_CHUVEIRO, INSTALACAO_SUPORTE): ");
                    CategoriaServico categoria = CategoriaServico.valueOf(scanner.nextLine().toUpperCase());
                    Cliente c = sistema.getClientes().get(0);
                    Profissional p = sistema.getProfissionais().get(0);
                    Servico servico = new Servico(sistema.getServicos().size() + 1, desc, categoria, c, p);
                    sistema.cadastrarServico(servico);
                    System.out.println("Serviço cadastrado com sucesso!");
                    break;
                case 4:
                    for (Servico s : sistema.getServicos()) {
                        System.out.println("ID: " + s.getId() + " - " + s.getDescricao() + " - " + s.getStatus());
                    }
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);

        scanner.close();
    }
}
