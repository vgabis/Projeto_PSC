package service;

import java.util.ArrayList;
import java.util.List;
import model.*;
import model.enums.*;

public class Sistema {
    private List<Cliente> clientes = new ArrayList<>();
    private List<Profissional> profissionais = new ArrayList<>();
    private List<Servico> servicos = new ArrayList<>();

    public void cadastrarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void cadastrarProfissional(Profissional profissional) {
        profissionais.add(profissional);
    }

    public void cadastrarServico(Servico servico) {
        servicos.add(servico);
        servico.getCliente().getServicosSolicitados().add(servico);
    }

    public List<Cliente> getClientes() { return clientes; }
    public List<Profissional> getProfissionais() { return profissionais; }
    public List<Servico> getServicos() { return servicos; }
}
